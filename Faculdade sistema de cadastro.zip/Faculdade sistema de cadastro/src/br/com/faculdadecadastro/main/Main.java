package br.com.faculdadecadastro.main;

import java.util.List;
import java.util.ArrayList;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import br.com.faculdadecadastro.models.*;
import br.com.faculdadecadastro.connection.*;
import java.sql.*;



public class Main {
    public static void main(String[] args) {
        // Criação das listas
        List<Professor> professores;
        professores = new ArrayList<>();

        List<Aluno> alunos;
        alunos = new ArrayList<>();

        List<FuncionarioAdm> funcionarioAdms;
        funcionarioAdms = new ArrayList<>();


        // Criação da interface

        JOptionPane form = new JOptionPane();
        JFrame frame = new JFrame("Registro");
        final JLabel label = new JLabel("Label");
        JButton button = new JButton("Professor");

        // Cria uma janela JFrame
        JFrame janela = new JFrame("Registro");
        janela.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Cria um painel JPanel
        JPanel painel = new JPanel();

        // Cria um botão JButton
        JButton botaoProf = new JButton("Professor");
        JButton botaoAluno = new JButton("Aluno");
        JButton botaoAdm = new JButton("Funcionario Administrativo");

        // Adiciona o botão ao painel
        painel.add(botaoProf);
        painel.add(botaoAluno);
        painel.add(botaoAdm);

        // Adiciona o painel à janela
        janela.add(painel);

        // Define o tamanho da janela
        janela.setSize(280, 120);

        // Deixando Visivel
        janela.setVisible(true);

        ActionListener actionListener = new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                JFrame professorFrame = new JFrame("Cadastro de Professor");

                // Criação dos campos de texto
                JTextField nomeField = new JTextField(30);
                JTextField cpfField = new JTextField(30);
                JTextField instituicaoField = new JTextField(30);
                JTextField qtdHoraField = new JTextField(30);
                JTextField valorHoraField = new JTextField(30);
                JTextField tituloField = new JTextField(30);

                // Criação do botão de salvar
                JButton salvarButton = new JButton("Salvar");

                // Configuração do layout
                professorFrame.setLayout(new BoxLayout(professorFrame.getContentPane(), BoxLayout.PAGE_AXIS));
                professorFrame.add(new JLabel("Nome:"));
                professorFrame.add(nomeField);
                professorFrame.add(new JLabel("CPF:"));
                professorFrame.add(cpfField);
                professorFrame.add(new JLabel("Instituição:"));
                professorFrame.add(instituicaoField);
                professorFrame.add(new JLabel("Quantidade de Horas:"));
                professorFrame.add(qtdHoraField);
                professorFrame.add(new JLabel("Valor da Hora:"));
                professorFrame.add(valorHoraField);
                professorFrame.add(new JLabel("Título:"));
                professorFrame.add(tituloField);
                professorFrame.add(salvarButton);

                // Configuração do botão de salvar
                salvarButton.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        String nome = nomeField.getText();
                        String cpf = cpfField.getText();
                        String instituicao = instituicaoField.getText();
                        double qtdHora = Double.parseDouble(qtdHoraField.getText());
                        double valorHora = Double.parseDouble(valorHoraField.getText());
                        String titulo = tituloField.getText();

                        Professor p1 = new Professor(qtdHora, valorHora, titulo);
                        p1.setNome(nome);
                        p1.setCpf(cpf);
                        p1.setInstituicao(instituicao);

                        // Conectar ao banco de dados
                        try (Connection connection = new sqlConnection().getConnection()) {
                            // Executar a inserção na tabela de professor
                            String sql = "INSERT INTO professor (nome, cpf, instituicao, qtdHora, valorHora, graduacao) VALUES (?, ?, ?, ?, ?, ?)";
                            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                                statement.setString(1, p1.getNome());
                                statement.setString(2, p1.getCpf());
                                statement.setString(3, p1.getInstituicao());
                                statement.setDouble(4, p1.getQtdHora());
                                statement.setDouble(5, p1.getValorHora());
                                statement.setString(6, p1.getGraduacao());
                                statement.executeUpdate();
                            }

                            JOptionPane.showMessageDialog(null, "Dados do professor registrados no banco de dados!");
                        } catch (SQLException ex) {
                            ex.printStackTrace();
                            JOptionPane.showMessageDialog(null, "Erro ao conectar ou inserir dados no banco de dados.");
                        } catch (ClassNotFoundException ex) {
                            throw new RuntimeException(ex);
                        }
                        System.out.print(p1);
                        professorFrame.dispose(); // Fecha a janela de cadastro de professor
                    }
                });

                professorFrame.pack();
                professorFrame.setVisible(true);
            }
        };

        // Adiciona o Action Listener ao botão
        botaoProf.addActionListener(actionListener);




        ActionListener actionListener2 = new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                JFrame alunoFrame = new JFrame("Cadastro do aluno");

                // Criação dos campos de texto
                JTextField nomeField = new JTextField(30);
                JTextField cpfField = new JTextField(30);
                JTextField instituicaoField = new JTextField(30);
                JTextField RAField = new JTextField(30);
                JTextField A1Field = new JTextField(30);
                JTextField A2Field = new JTextField(30);
                JTextField A3Field = new JTextField(30);

                // Criação do botão de salvar
                JButton salvarButton = new JButton("Salvar");

                // Configuração do layout
                alunoFrame.setLayout(new BoxLayout(alunoFrame.getContentPane(), BoxLayout.PAGE_AXIS));
                alunoFrame.add(new JLabel("Nome:"));
                alunoFrame.add(nomeField);
                alunoFrame.add(new JLabel("CPF:"));
                alunoFrame.add(cpfField);
                alunoFrame.add(new JLabel("Instituição:"));
                alunoFrame.add(instituicaoField);
                alunoFrame.add(new JLabel("RA:"));
                alunoFrame.add(RAField);
                alunoFrame.add(new JLabel("A1:"));
                alunoFrame.add(A1Field);
                alunoFrame.add(new JLabel("A2:"));
                alunoFrame.add(A2Field);
                alunoFrame.add(new JLabel("A3:"));
                alunoFrame.add(A3Field);
                alunoFrame.add(salvarButton);

                // Configuração do botão de salvar
                salvarButton.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        String nome = nomeField.getText();
                        String cpf = cpfField.getText();
                        String instituicao = instituicaoField.getText();
                        String RA = RAField.getText();
                        double A1 = Double.parseDouble(A1Field.getText());
                        double A2 = Double.parseDouble(A2Field.getText());
                        double A3 = Double.parseDouble(A3Field.getText());

                        Aluno a1 = new Aluno(RA, A1, A2, A3);
                        a1.setNome(nome);
                        a1.setCpf(cpf);
                        a1.setInstituicao(instituicao);

                        // Conectar ao banco de dados
                        try (Connection connection = new sqlConnection().getConnection()) {
                            // Executar a inserção na tabela de Aluno
                            String sql = "INSERT INTO aluno (nome, cpf, instituicao, A1, A2, A3, RA) VALUES (?, ?, ?, ?, ?, ?, ?)";
                            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                                statement.setString(1, a1.getNome());
                                statement.setString(2, a1.getCpf());
                                statement.setString(3, a1.getInstituicao());
                                statement.setDouble(4, a1.getA1());
                                statement.setDouble(5, a1.getA2());
                                statement.setDouble(6, a1.getA3());
                                statement.setString(7, a1.getRA());
                                statement.executeUpdate();
                            }

                            JOptionPane.showMessageDialog(null, "Dados do aluno registrados no banco de dados!");
                        } catch (SQLException ex) {
                            ex.printStackTrace();
                            JOptionPane.showMessageDialog(null, "Erro ao conectar ou inserir dados no banco de dados.");
                        } catch (ClassNotFoundException ex) {
                            throw new RuntimeException(ex);
                        }
                        System.out.print(a1);
                        alunoFrame.dispose(); // Fecha a janela de cadastro de professor
                    }
                });

                alunoFrame.pack();
                alunoFrame.setVisible(true);
            }
        };

        // Adiciona o Action Listener ao botão
        botaoAluno.addActionListener(actionListener2);

        ActionListener actionListener3 = new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                JFrame funcAdmFrame = new JFrame("Cadastro do Funcionario Administrativo");

                // Criação dos campos de texto
                JTextField nomeField = new JTextField(30);
                JTextField cpfField = new JTextField(30);
                JTextField instituicaoField = new JTextField(30);
                JTextField qtdHoraField = new JTextField(30);
                JTextField valorHoraField = new JTextField(30);
                JTextField funcaoField = new JTextField(30);

                // Criação do botão de salvar
                JButton salvarButton = new JButton("Salvar");

                // Configuração do layout
                funcAdmFrame.setLayout(new BoxLayout(funcAdmFrame.getContentPane(), BoxLayout.PAGE_AXIS));
                funcAdmFrame.add(new JLabel("Nome:"));
                funcAdmFrame.add(nomeField);
                funcAdmFrame.add(new JLabel("CPF:"));
                funcAdmFrame.add(cpfField);
                funcAdmFrame.add(new JLabel("Instituição:"));
                funcAdmFrame.add(instituicaoField);
                funcAdmFrame.add(new JLabel("Quantidade de Horas:"));
                funcAdmFrame.add(qtdHoraField);
                funcAdmFrame.add(new JLabel("Valor da Hora:"));
                funcAdmFrame.add(valorHoraField);
                funcAdmFrame.add(new JLabel("Função:"));
                funcAdmFrame.add(funcaoField);
                funcAdmFrame.add(salvarButton);

                // Configuração do botão de salvar
                salvarButton.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        String nome = nomeField.getText();
                        String cpf = cpfField.getText();
                        String instituicao = instituicaoField.getText();
                        double qtdHora = Double.parseDouble(qtdHoraField.getText());
                        double valorHora = Double.parseDouble(valorHoraField.getText());
                        String funcao = funcaoField.getText();

                        FuncionarioAdm fa1 = new FuncionarioAdm(qtdHora, valorHora, funcao);
                        fa1.setNome(nome);
                        fa1.setCpf(cpf);
                        fa1.setInstituicao(instituicao);


                        // Conectar ao banco de dados
                        try (Connection connection = new sqlConnection().getConnection()) {
                            // Executar a inserção na tabela de professor
                            String sql = "INSERT INTO funcionarioadm (nome, cpf, instituicao, qtdHora, valorHora, funcao) VALUES (?, ?, ?, ?, ?, ?)";
                            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                                statement.setString(1, fa1.getNome());
                                statement.setString(2, fa1.getCpf());
                                statement.setString(3, fa1.getInstituicao());
                                statement.setDouble(4, fa1.getQtdHora());
                                statement.setDouble(5, fa1.getValorHora());
                                statement.setString(6, fa1.getFuncao());
                                statement.executeUpdate();
                            }

                            JOptionPane.showMessageDialog(null, "Dados do funcionario administrativo registrados no banco de dados!");
                        } catch (SQLException ex) {
                            ex.printStackTrace();
                            JOptionPane.showMessageDialog(null, "Erro ao conectar ou inserir dados no banco de dados.");
                        } catch (ClassNotFoundException ex) {
                            throw new RuntimeException(ex);
                        }
                        System.out.print(fa1);
                        funcAdmFrame.dispose(); // Fecha a janela de cadastro de professor
                    }
                });

                funcAdmFrame.pack();
                funcAdmFrame.setVisible(true);
            }
        };
        // Adiciona o Action Listener ao botão
        botaoAdm.addActionListener(actionListener3);
    }
}