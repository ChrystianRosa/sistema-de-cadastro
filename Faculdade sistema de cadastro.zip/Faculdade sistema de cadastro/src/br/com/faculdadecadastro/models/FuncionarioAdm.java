package br.com.faculdadecadastro.models;

public class FuncionarioAdm extends Pessoa{

    private double QtdHora, ValorHora;
    private String Funcao;

    @Override
    public String toString() {
        return "Nome do Funcionario Administrativo: " + getNome() +
                "\nQtdHora =" + QtdHora +
                "\nValorHora =" + ValorHora +
                "\nFuncao =" + Funcao +
                "\nSalario =" + getSalario();
    }

    public double getQtdHora() {
        return QtdHora;
    }

    public void setQtdHora(double qtdHora) {
        QtdHora = qtdHora;
    }

    public double getValorHora() {
        return ValorHora;
    }

    public void setValorHora(double valorHora) {
        ValorHora = valorHora;
    }

    public String getFuncao() {
        return Funcao;
    }

    public void setFuncap(String funcao) {
        Funcao = funcao;
    }

    public FuncionarioAdm(double qtdHora, double valorHora, String funcao) {
        QtdHora = qtdHora;
        ValorHora = valorHora;
        Funcao = funcao;
    }
    public double getSalario(){
        double salario = QtdHora * ValorHora;
        return salario;
    }

}