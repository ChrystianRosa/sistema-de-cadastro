package br.com.faculdadecadastro.models;

public class
Professor extends Pessoa{
    public Professor(double qtdHora, double valorHora, String graduacao) {
        QtdHora = qtdHora;
        ValorHora = valorHora;
        Graduacao = graduacao;
    }

    private double QtdHora, ValorHora;
    private String Graduacao;

    @Override
    public String toString() {
        return "Professor: " + getNome() +
                "\nCPF: " + getCpf() +
                "\nInsitituição de Ensino: " + getInstituicao() +
                "\nQtdHora = " + QtdHora +
                "\nValorHora = " + ValorHora +
                "\nGraduacao = " + Graduacao +
                "\nSalario = R$" + getSalario();
    }

    public double getQtdHora() {
        return QtdHora;
    }

    public void setQtdHora(double qtdHora) {
        QtdHora = qtdHora;
    }

    public double getValorHora() {
        return ValorHora;
    }

    public void setValorHora(double valorHora) {
        ValorHora = valorHora;
    }

    public String getGraduacao() {
        return Graduacao;
    }

    public void setGraduacao(String graduacao) {
        Graduacao = graduacao;
    }
    public double getSalario(){
        double x = 0;
        if(Graduacao.equals("Especialista")){
            x = 1.10;
        } else if(Graduacao.equals("Mestre")){
            x = 1.15;
        } else if(Graduacao.equals("Doutor")){
            x = 1.20;
        }
        double salario = QtdHora * ValorHora * x;
        return salario;
    }
}
