package br.com.faculdadecadastro.models;

public class Aluno extends Pessoa {
    private String RA;
    private double A1, A2, A3;
    public Aluno(String RA, double a1, double a2, double a3) {
        this.RA = RA;
        A1 = a1;
        A2 = a2;
        A3 = a3;
    }

    public String getRA() {
        return RA;
    }

    public void setRA(String RA) {
        this.RA = RA;
    }

    public double getA1() {
        return A1;
    }

    public void setA1(double a1) {
        A1 = a1;
    }

    public double getA2() {
        return A2;
    }

    public void setA2(double a2) {
        A2 = a2;
    }

    public double getA3() {
        return A3;
    }

    public void setA3(double a3) {
        A3 = a3;
    }

    @Override
    public String toString() {
        return "Aluno:" + getNome() +
                "\nRA:" + RA +
                "\nA1 =" + A1 +
                "\nA2 =" + A2 +
                "\nA3 =" + A3 +
                "\nNota = " + mediaAri();
    }
    public double mediaAri(){
        double media = (A1 + A2 + A3) / 3;
        return media;
    }
}
